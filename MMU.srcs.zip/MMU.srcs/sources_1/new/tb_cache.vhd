library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.MMU_package.all;

entity tb_cache is
end tb_cache;

architecture Behavioral of tb_cache is

    component cache
        Port (
            clk            : in  std_logic;
            rst            : in  std_logic;

            proc_read      : in  std_logic;
            proc_write     : in  std_logic;
            proc_addr      : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
            proc_data_in   : in  std_logic_vector(DATA_WIDTH-1 downto 0);
            proc_data_out  : out std_logic_vector(DATA_WIDTH-1 downto 0);
            proc_ready     : out std_logic;

            bus_cmd_out    : out bus_cmd;
            bus_addr_out   : out std_logic_vector(ADDR_WIDTH-1 downto 0);
            bus_data_out   : out std_logic_vector(LINE_SIZE*DATA_WIDTH-1 downto 0);

            bus_data_in    : in  std_logic_vector(LINE_SIZE*DATA_WIDTH-1 downto 0);
            bus_ready      : in  std_logic;
            bus_shared_in  : in  std_logic;

            snoop_cmd      : in  bus_cmd;
            snoop_addr     : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
            snoop_valid    : in  std_logic;
            snoop_data_out : out std_logic_vector(LINE_SIZE*DATA_WIDTH-1 downto 0);
            snoop_hit      : out std_logic
        );
    end component;

    signal clk : std_logic := '0';
    signal rst : std_logic := '0';

    signal proc_read     : std_logic := '0';
    signal proc_write    : std_logic := '0';
    signal proc_addr     : std_logic_vector(ADDR_WIDTH-1 downto 0) := (others => '0');
    signal proc_data_in  : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal proc_data_out : std_logic_vector(DATA_WIDTH-1 downto 0);
    signal proc_ready    : std_logic;

    signal bus_cmd_out   : bus_cmd;
    signal bus_addr_out  : std_logic_vector(ADDR_WIDTH-1 downto 0);
    signal bus_data_out  : std_logic_vector(LINE_SIZE*DATA_WIDTH-1 downto 0);
    signal bus_data_in   : std_logic_vector(LINE_SIZE*DATA_WIDTH-1 downto 0) := (others => '0');
    signal bus_ready     : std_logic := '0';
    signal bus_shared_in : std_logic := '0';

    signal snoop_cmd      : bus_cmd := BUS_IDLE;
    signal snoop_addr     : std_logic_vector(ADDR_WIDTH-1 downto 0) := (others => '0');
    signal snoop_valid    : std_logic := '0';
    signal snoop_data_out : std_logic_vector(LINE_SIZE*DATA_WIDTH-1 downto 0);
    signal snoop_hit      : std_logic;

    constant CLK_PERIOD : time := 10 ns;
    signal done : boolean := false;

    -- helpers that avoid X"..." and avoid large integers
    function uaddr(n : natural) return std_logic_vector is
    begin
        return std_logic_vector(to_unsigned(n, ADDR_WIDTH));
    end function;

    function u8(n : natural) return std_logic_vector is
    begin
        return std_logic_vector(to_unsigned(n mod 256, DATA_WIDTH)); -- DATA_WIDTH=8
    end function;

begin

    uut: cache
        port map (
            clk            => clk,
            rst            => rst,
            proc_read      => proc_read,
            proc_write     => proc_write,
            proc_addr      => proc_addr,
            proc_data_in   => proc_data_in,
            proc_data_out  => proc_data_out,
            proc_ready     => proc_ready,
            bus_cmd_out    => bus_cmd_out,
            bus_addr_out   => bus_addr_out,
            bus_data_out   => bus_data_out,
            bus_data_in    => bus_data_in,
            bus_ready      => bus_ready,
            bus_shared_in  => bus_shared_in,
            snoop_cmd      => snoop_cmd,
            snoop_addr     => snoop_addr,
            snoop_valid    => snoop_valid,
            snoop_data_out => snoop_data_out,
            snoop_hit      => snoop_hit
        );

    -- clock
    clk_gen: process
    begin
        while not done loop
            clk <= '0'; wait for CLK_PERIOD/2;
            clk <= '1'; wait for CLK_PERIOD/2;
        end loop;
        wait;
    end process;

    -- minimal "memory controller" model:
    -- responds after 2 cycles; for BUS_RD/BUS_RDX returns 4 bytes:
    -- byte0=a8+0, byte1=a8+1, byte2=a8+2, byte3=a8+3 (mod 256)
    bus_model: process(clk)
        variable wait_cycles : integer := 0;
        variable a8 : natural;
        variable b0, b1, b2, b3 : std_logic_vector(7 downto 0);
    begin
        if rising_edge(clk) then
            bus_ready <= '0';

            if bus_cmd_out /= BUS_IDLE then
                wait_cycles := wait_cycles + 1;

                if wait_cycles = 2 then
                    bus_ready   <= '1';
                    wait_cycles := 0;

                    if (bus_cmd_out = BUS_RD) or (bus_cmd_out = BUS_RDX) then
                        a8 := to_integer(unsigned(bus_addr_out(7 downto 0)));

                        b0 := u8(a8 + 0);
                        b1 := u8(a8 + 1);
                        b2 := u8(a8 + 2);
                        b3 := u8(a8 + 3);

                        -- Cache line is 4 bytes = 32 bits total.
                        -- Put b3 as MSB ... b0 as LSB.
                        bus_data_in <= b3 & b2 & b1 & b0;
                        bus_shared_in <= '0';
                    end if;
                end if;
            else
                wait_cycles := 0;
            end if;
        end if;
    end process;

    stim: process
        procedure wait_ready is
        begin
            for k in 0 to 200 loop
                wait until rising_edge(clk);
                exit when proc_ready = '1';
            end loop;
            if proc_ready /= '1' then
                report "TIMEOUT waiting for proc_ready" severity failure;
            end if;
        end procedure;

        procedure do_read(a : std_logic_vector(ADDR_WIDTH-1 downto 0)) is
        begin
            proc_addr <= a;
            proc_read <= '1';
            wait until rising_edge(clk);
            proc_read <= '0';
            wait_ready;
        end procedure;

        procedure do_write(a : std_logic_vector(ADDR_WIDTH-1 downto 0);
                           d : std_logic_vector(DATA_WIDTH-1 downto 0)) is
        begin
            proc_addr    <= a;
            proc_data_in <= d;
            proc_write   <= '1';
            wait until rising_edge(clk);
            proc_write   <= '0';
            wait_ready;
        end procedure;

        function expected_byte(base_addr : natural; offset : natural) return std_logic_vector is
        begin
            -- base is bus_addr_out[7:0] in our model; offset is 0..3 inside line
            return u8(base_addr + offset);
        end function;

    begin
        -- reset
        report "TB: reset" severity note;
        rst <= '1';
        wait for 5*CLK_PERIOD;
        rst <= '0';
        wait for 2*CLK_PERIOD;

        -- Test 1: read miss at 0x00 => should fetch line, offset 0 => byte0 = 0
        report "TB: Test 1 read miss @0" severity note;
        do_read(uaddr(0));
        assert proc_data_out = expected_byte(0, 0)
            report "Test 1 FAILED" severity failure;

        -- Test 2: read hit same line at 0x01 => offset 1 => byte1 = 1
        report "TB: Test 2 read hit @1" severity note;
        do_read(uaddr(1));
        assert proc_data_out = expected_byte(0, 1)
            report "Test 2 FAILED" severity failure;

        -- Test 3: write hit at 0x02 with 0xAB, then read back
        report "TB: Test 3 write+readback @2" severity note;
        do_write(uaddr(2), u8(16#AB#));
        do_read(uaddr(2));
        assert proc_data_out = u8(16#AB#)
            report "Test 3 FAILED" severity failure;

        -- Test 4: snoop BUS_RD at 0x02 should hit; if line is M, cache provides full line
        report "TB: Test 4 snoop BUS_RD @2" severity note;
        snoop_cmd   <= BUS_RD;
        snoop_addr  <= uaddr(2);
        snoop_valid <= '1';
        wait until rising_edge(clk);
        wait until rising_edge(clk);
        snoop_valid <= '0';

        assert snoop_hit = '1'
            report "Test 4 FAILED: snoop should hit" severity failure;

        -- Because we wrote, your cache should be M, so it should drive snoop_data_out = cached line.
        -- Check the byte at offset 2 (third byte) equals 0xAB.
        assert snoop_data_out((2+1)*DATA_WIDTH-1 downto 2*DATA_WIDTH) = u8(16#AB#)
            report "Test 4 FAILED: snoop data mismatch" severity failure;

        -- Test 5: snoop BUS_RDX invalidates the line
        report "TB: Test 5 snoop BUS_RDX @2 (invalidate)" severity note;
        snoop_cmd   <= BUS_RDX;
        snoop_addr  <= uaddr(2);
        snoop_valid <= '1';
        wait until rising_edge(clk);
        wait until rising_edge(clk);
        snoop_valid <= '0';

        assert snoop_hit = '1'
            report "Test 5 FAILED: snoop should hit" severity failure;

        -- Test 6: read again @2 => miss refill => expected byte2 = 2 (since base addr 0)
        report "TB: Test 6 read after invalidation @2" severity note;
        do_read(uaddr(2));
        assert proc_data_out = expected_byte(0, 2)
            report "Test 6 FAILED" severity failure;

        report "TB: ALL TESTS PASSED" severity note;
        done <= true;
        wait;
    end process;

end Behavioral;
