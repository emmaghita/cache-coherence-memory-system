library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

use work.MMU_package.all;

entity tb_MainMemory is
end tb_MainMemory;

architecture sim of tb_MainMemory is

    -- DUT signals
    signal clk          : std_logic := '0';
    signal rst          : std_logic := '0';
    signal mem_read     : std_logic := '0';
    signal mem_write    : std_logic := '0';
    signal mem_addr     : std_logic_vector(ADDR_WIDTH - 1 downto 0) := (others => '0');
    signal mem_data_in  : std_logic_vector((LINE_SIZE*DATA_WIDTH)-1 downto 0) := (others => '0');
    signal mem_data_out : std_logic_vector((LINE_SIZE*DATA_WIDTH)-1 downto 0);
    signal mem_ready    : std_logic;

    constant CLK_PERIOD : time := 10 ns;

    function init_line(line_idx : integer) return std_logic_vector is
        variable tmp : std_logic_vector(LINE_SIZE*DATA_WIDTH - 1 downto 0);
    begin
        for j in 0 to LINE_SIZE-1 loop
            tmp((j+1)*DATA_WIDTH-1 downto j*DATA_WIDTH) :=
                std_logic_vector(to_unsigned(line_idx*LINE_SIZE + j, DATA_WIDTH));
        end loop;
        return tmp;
    end function;

    function custom_line(base_val : integer) return std_logic_vector is
        variable tmp : std_logic_vector(LINE_SIZE*DATA_WIDTH - 1 downto 0);
    begin
        for j in 0 to LINE_SIZE-1 loop
            tmp((j+1)*DATA_WIDTH-1 downto j*DATA_WIDTH) :=
                std_logic_vector(to_unsigned(base_val + j, DATA_WIDTH));
        end loop;
        return tmp;
    end function;

begin

    clk <= not clk after CLK_PERIOD/2;

    DUT: entity work.MainMemory
        port map(
            clk          => clk,
            rst          => rst,
            mem_read     => mem_read,
            mem_write    => mem_write,
            mem_addr     => mem_addr,
            mem_data_in  => mem_data_in,
            mem_data_out => mem_data_out,
            mem_ready    => mem_ready
        );

    stimulus: process
        variable expected : std_logic_vector(LINE_SIZE*DATA_WIDTH - 1 downto 0);
    begin

        -- 1. RESET
        rst <= '1';
        wait for 2*CLK_PERIOD;
        wait until rising_edge(clk);
        rst <= '0';
        wait until rising_edge(clk);

        -- 2. READ line 0
        mem_addr <= std_logic_vector(to_unsigned(0*4, ADDR_WIDTH));
        mem_read <= '1';
        wait until rising_edge(clk);
        wait for 0 ns;

        expected := init_line(0);
        assert mem_ready = '1'
            report "READ line 0: mem_ready not asserted"
            severity error;

        assert mem_data_out = expected
            report "READ line 0: data mismatch after reset"
            severity error;

        mem_read <= '0';
        wait until rising_edge(clk);

        -- 3. READ line 3
        mem_addr <= std_logic_vector(to_unsigned(3*4, ADDR_WIDTH));
        mem_read <= '1';
        wait until rising_edge(clk);
        wait for 0 ns;  

        expected := init_line(3);
        assert mem_ready = '1'
            report "READ line 3: mem_ready not asserted"
            severity error;

        assert mem_data_out = expected
            report "READ line 3: data mismatch after reset"
            severity error;

        mem_read <= '0';
        wait until rising_edge(clk);

        -- 4. WRITE line 2
        mem_addr    <= std_logic_vector(to_unsigned(2*4, ADDR_WIDTH));
        mem_data_in <= custom_line(100);
        mem_write   <= '1';
        wait until rising_edge(clk);
        wait for 0 ns;  

        assert mem_ready = '1'
            report "WRITE line 2: mem_ready not asserted"
            severity error;

        mem_write <= '0';
        wait until rising_edge(clk);

        -- 5. READBACK line 2
        mem_addr <= std_logic_vector(to_unsigned(2*4, ADDR_WIDTH));
        mem_read <= '1';
        wait until rising_edge(clk);
        wait for 0 ns; 

        expected := custom_line(100);
        assert mem_ready = '1'
            report "READBACK line 2: mem_ready not asserted"
            severity error;

        assert mem_data_out = expected
            report "READBACK line 2: data mismatch after write"
            severity error;

        mem_read <= '0';
        wait until rising_edge(clk);

        report "All MainMemory tests PASSED." severity note;
        wait;
    end process;

end sim;
