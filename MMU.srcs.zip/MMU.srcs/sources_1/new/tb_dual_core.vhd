library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

-- Ensure MMU_package (containing ADDR_WIDTH, DATA_WIDTH, bus_cmd, mesi_state) 
-- and the entity definitions for cache, memory_ctrl, and MainMemory are compiled.
use work.MMU_package.all;

entity tb_dual_core is
end tb_dual_core;

architecture Behavioral of tb_dual_core is

    -- System Constants
    constant C_CLK_PERIOD : time := 10 ns;
    constant C_BUS_WIDTH  : integer := LINE_SIZE * DATA_WIDTH;

    -- Component Declarations (Required for instantiation)
    
    component cache is
        Port ( 
            clk           : in  std_logic;
            rst           : in  std_logic;
            proc_read     : in  std_logic;
            proc_write    : in  std_logic;
            proc_addr     : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
            proc_data_in  : in  std_logic_vector(DATA_WIDTH-1 downto 0);
            proc_data_out : out std_logic_vector(DATA_WIDTH-1 downto 0);
            proc_ready    : out std_logic;
            bus_cmd_out   : out bus_cmd;
            bus_addr_out  : out std_logic_vector(ADDR_WIDTH-1 downto 0);
            bus_data_out  : out std_logic_vector(C_BUS_WIDTH-1 downto 0);
            bus_data_in   : in  std_logic_vector(C_BUS_WIDTH-1 downto 0);
            bus_ready     : in  std_logic;
            bus_shared_in : in  std_logic;
            snoop_cmd     : in  bus_cmd;
            snoop_addr    : in  std_logic_vector(ADDR_WIDTH-1 downto 0);
            snoop_valid   : in  std_logic;
            snoop_data_out: out std_logic_vector(C_BUS_WIDTH-1 downto 0);
            snoop_hit     : out std_logic
        );
    end component;

    component memory_ctrl is
        port (
            clk             : in std_logic;
            rst             : in std_logic;
            c0_bus_cmd_in   : in bus_cmd;
            c0_bus_addr_in  : in std_logic_vector(ADDR_WIDTH-1 downto 0);
            c0_bus_data_in  : in std_logic_vector(C_BUS_WIDTH-1 downto 0);
            c0_bus_data_out : out std_logic_vector(C_BUS_WIDTH-1 downto 0);
            c0_bus_ready    : out std_logic;
            c0_bus_shared   : out std_logic;
            c0_snoop_cmd    : out bus_cmd;
            c0_snoop_addr   : out std_logic_vector(ADDR_WIDTH-1 downto 0);
            c0_snoop_valid  : out std_logic;
            c0_snoop_data   : in std_logic_vector(C_BUS_WIDTH-1 downto 0);
            c0_snoop_hit    : in std_logic;
            c1_bus_cmd_in   : in bus_cmd;
            c1_bus_addr_in  : in std_logic_vector(ADDR_WIDTH-1 downto 0);
            c1_bus_data_in  : in std_logic_vector(C_BUS_WIDTH-1 downto 0);
            c1_bus_data_out : out std_logic_vector(C_BUS_WIDTH-1 downto 0);
            c1_bus_ready    : out std_logic;
            c1_bus_shared   : out std_logic;
            c1_snoop_cmd    : out bus_cmd;
            c1_snoop_addr   : out std_logic_vector(ADDR_WIDTH-1 downto 0);
            c1_snoop_valid  : out std_logic;
            c1_snoop_data   : in std_logic_vector(C_BUS_WIDTH-1 downto 0);
            c1_snoop_hit    : in std_logic;
            mem_read        : out std_logic;
            mem_write       : out std_logic;
            mem_addr        : out std_logic_vector(ADDR_WIDTH-1 downto 0);
            mem_data_in     : out std_logic_vector(C_BUS_WIDTH-1 downto 0);
            mem_data_out    : in std_logic_vector(C_BUS_WIDTH-1 downto 0);
            mem_ready       : in std_logic
        );
    end component;

    component MainMemory is
        Port ( 
            clk          : in std_logic;
            rst          : in std_logic;
            mem_read     : in std_logic;
            mem_write    : in std_logic;
            mem_addr     : in std_logic_vector(ADDR_WIDTH - 1 downto 0);
            mem_data_in  : in  std_logic_vector(C_BUS_WIDTH-1 downto 0); 
            mem_data_out : out std_logic_vector(C_BUS_WIDTH - 1 downto 0);
            mem_ready    : out std_logic
        );
    end component;

    -- Signal Declarations (As defined in the previous response)
    signal clk_s             : std_logic := '0';
    signal rst_s             : std_logic := '1';
    
    -- CPU 0 Interface
    signal c0_proc_read_s       : std_logic := '0';
    signal c0_proc_write_s      : std_logic := '0';
    signal c0_proc_addr_s       : std_logic_vector(ADDR_WIDTH-1 downto 0) := (others => '0');
    signal c0_proc_data_in_s    : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal c0_proc_data_out_s   : std_logic_vector(DATA_WIDTH-1 downto 0);
    signal c0_proc_ready_s      : std_logic;
    
    -- CPU 1 Interface
    signal c1_proc_read_s       : std_logic := '0';
    signal c1_proc_write_s      : std_logic := '0';
    signal c1_proc_addr_s       : std_logic_vector(ADDR_WIDTH-1 downto 0) := (others => '0');
    signal c1_proc_data_in_s    : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal c1_proc_data_out_s   : std_logic_vector(DATA_WIDTH-1 downto 0);
    signal c1_proc_ready_s      : std_logic;

    -- Cache 0 <-> Memory Controller Signals
    signal c0_bus_cmd_out_s     : bus_cmd;
    signal c0_bus_addr_out_s    : std_logic_vector(ADDR_WIDTH-1 downto 0);
    signal c0_bus_data_out_s    : std_logic_vector(C_BUS_WIDTH-1 downto 0);
    signal c0_bus_data_in_s     : std_logic_vector(C_BUS_WIDTH-1 downto 0);
    signal c0_bus_ready_s       : std_logic;
    signal c0_bus_shared_s      : std_logic;
    signal c0_snoop_cmd_s       : bus_cmd;
    signal c0_snoop_addr_s      : std_logic_vector(ADDR_WIDTH-1 downto 0);
    signal c0_snoop_valid_s     : std_logic;
    signal c0_snoop_data_s      : std_logic_vector(C_BUS_WIDTH-1 downto 0);
    signal c0_snoop_hit_s       : std_logic;

    -- Cache 1 <-> Memory Controller Signals
    signal c1_bus_cmd_out_s     : bus_cmd;
    signal c1_bus_addr_out_s    : std_logic_vector(ADDR_WIDTH-1 downto 0);
    signal c1_bus_data_out_s    : std_logic_vector(C_BUS_WIDTH-1 downto 0);
    signal c1_bus_data_in_s     : std_logic_vector(C_BUS_WIDTH-1 downto 0);
    signal c1_bus_ready_s       : std_logic;
    signal c1_bus_shared_s      : std_logic;
    signal c1_snoop_cmd_s       : bus_cmd;
    signal c1_snoop_addr_s      : std_logic_vector(ADDR_WIDTH-1 downto 0);
    signal c1_snoop_valid_s     : std_logic;
    signal c1_snoop_data_s      : std_logic_vector(C_BUS_WIDTH-1 downto 0);
    signal c1_snoop_hit_s       : std_logic;
    
    -- Memory Controller <-> Main Memory Signals
    signal mem_read_s           : std_logic;
    signal mem_write_s          : std_logic;
    signal mem_addr_s           : std_logic_vector(ADDR_WIDTH-1 downto 0);
    signal mem_data_in_s        : std_logic_vector(C_BUS_WIDTH-1 downto 0);
    signal mem_data_out_s       : std_logic_vector(C_BUS_WIDTH-1 downto 0);
    signal mem_ready_s          : std_logic;

    -- Test Addresses and Data (Targeting Index 00, Word 0)
    constant CONFLICT_ADDR      : std_logic_vector(ADDR_WIDTH-1 downto 0) := X"00";
    constant C0_WRITE_DATA      : std_logic_vector(DATA_WIDTH-1 downto 0) := X"AA";
    constant C1_WRITE_DATA      : std_logic_vector(DATA_WIDTH-1 downto 0) := X"BB";
    constant DUMMY_DATA         : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');

begin
    -- *******************************************************
    -- 1. INSTANTIATIONS
    -- *******************************************************
    UUT_CACHE0: cache
        port map (
            clk => clk_s, rst => rst_s,
            proc_read => c0_proc_read_s, proc_write => c0_proc_write_s,
            proc_addr => c0_proc_addr_s, proc_data_in => c0_proc_data_in_s,
            proc_data_out => c0_proc_data_out_s, proc_ready => c0_proc_ready_s,
            bus_cmd_out => c0_bus_cmd_out_s, bus_addr_out => c0_bus_addr_out_s,
            bus_data_out => c0_bus_data_out_s, bus_data_in => c0_bus_data_in_s,
            bus_ready => c0_bus_ready_s, bus_shared_in => c0_bus_shared_s,
            snoop_cmd => c0_snoop_cmd_s, snoop_addr => c0_snoop_addr_s,
            snoop_valid => c0_snoop_valid_s, snoop_data_out => c0_snoop_data_s,
            snoop_hit => c0_snoop_hit_s
        );

    UUT_CACHE1: cache
        port map (
            clk => clk_s, rst => rst_s,
            proc_read => c1_proc_read_s, proc_write => c1_proc_write_s,
            proc_addr => c1_proc_addr_s, proc_data_in => c1_proc_data_in_s,
            proc_data_out => c1_proc_data_out_s, proc_ready => c1_proc_ready_s,
            bus_cmd_out => c1_bus_cmd_out_s, bus_addr_out => c1_bus_addr_out_s,
            bus_data_out => c1_bus_data_out_s, bus_data_in => c1_bus_data_in_s,
            bus_ready => c1_bus_ready_s, bus_shared_in => c1_bus_shared_s,
            snoop_cmd => c1_snoop_cmd_s, snoop_addr => c1_snoop_addr_s,
            snoop_valid => c1_snoop_valid_s, snoop_data_out => c1_snoop_data_s,
            snoop_hit => c1_snoop_hit_s
        );

    UUT_MC: memory_ctrl
        port map (
            clk => clk_s, rst => rst_s,
            -- Cache 0 Interface
            c0_bus_cmd_in => c0_bus_cmd_out_s, c0_bus_addr_in => c0_bus_addr_out_s,
            c0_bus_data_in => c0_bus_data_out_s, c0_bus_data_out => c0_bus_data_in_s,
            c0_bus_ready => c0_bus_ready_s, c0_bus_shared => c0_bus_shared_s,
            c0_snoop_cmd => c0_snoop_cmd_s, c0_snoop_addr => c0_snoop_addr_s,
            c0_snoop_valid => c0_snoop_valid_s, c0_snoop_data => c0_snoop_data_s,
            c0_snoop_hit => c0_snoop_hit_s,
            -- Cache 1 Interface
            c1_bus_cmd_in => c1_bus_cmd_out_s, c1_bus_addr_in => c1_bus_addr_out_s,
            c1_bus_data_in => c1_bus_data_out_s, c1_bus_data_out => c1_bus_data_in_s,
            c1_bus_ready => c1_bus_ready_s, c1_bus_shared => c1_bus_shared_s,
            c1_snoop_cmd => c1_snoop_cmd_s, c1_snoop_addr => c1_snoop_addr_s,
            c1_snoop_valid => c1_snoop_valid_s, c1_snoop_data => c1_snoop_data_s,
            c1_snoop_hit => c1_snoop_hit_s, 
            -- Main Memory Interface
            mem_read => mem_read_s, mem_write => mem_write_s,
            mem_addr => mem_addr_s, mem_data_in => mem_data_in_s,
            mem_data_out => mem_data_out_s, mem_ready => mem_ready_s
        );
    
    UUT_MEM: MainMemory
        port map (
            clk => clk_s, rst => rst_s,
            mem_read => mem_read_s, mem_write => mem_write_s,
            mem_addr => mem_addr_s, mem_data_in => mem_data_in_s,
            mem_data_out => mem_data_out_s, mem_ready => mem_ready_s
        );

    -- *******************************************************
    -- 2. CLOCK AND RESET
    -- *******************************************************
    clk_proc: process
    begin
        clk_s <= '0';
        wait for C_CLK_PERIOD / 2;
        loop
            clk_s <= '1';
            wait for C_CLK_PERIOD / 2;
            clk_s <= '0';
            wait for C_CLK_PERIOD / 2;
        end loop;
    end process clk_proc;

    -- *******************************************************
    -- 3. TEST STIMULUS GENERATOR (C0/C1)
    -- *******************************************************
    
    -- Helper procedure to send a CPU request (for either C0 or C1)
    procedure send_request (
        signal read_en  : out std_logic;
        signal write_en : out std_logic;
        signal addr     : out std_logic_vector;
        signal data     : out std_logic_vector;
        is_read_op      : in boolean;
        req_addr        : in std_logic_vector(ADDR_WIDTH-1 downto 0);
        req_data        : in std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0')
    ) is
    begin
        read_en    <= '1' when is_read_op else '0';
        write_en   <= '1' when not is_read_op else '0';
        addr       <= req_addr;
        data       <= req_data;
        wait for C_CLK_PERIOD;
        read_en    <= '0';
        write_en   <= '0';
        data       <= (others => '0');
    end procedure send_request;

    stim_proc: process
    begin
        -- Initial Reset
        rst_s <= '1';
        wait for 2 * C_CLK_PERIOD;
        rst_s <= '0';
        wait for C_CLK_PERIOD;
        
        -- Memory Initialization Check (Word 0 address 0x00 contains 0x00)
        
        -- =======================================================
        -- TEST 1: I -> E -> S Transition (Read Sharing)
        -- =======================================================
        report "--- TEST 1: I -> E -> S Transition (Read Sharing) ---" severity NOTE;

        -- Step 1.1: C0 Read Miss. State: I -> E. (Data from Mem)
        report "T1.1 C0: Read Miss on 0x00. Expect I -> E." severity NOTE;
        send_request(c0_proc_read_s, c0_proc_write_s, c0_proc_addr_s, c0_proc_data_in_s, 
                     true, CONFLICT_ADDR, DUMMY_DATA);
        wait until c0_proc_ready_s = '1'; 
        assert c0_proc_data_out_s = X"00" report "T1.1 FAILED: C0 failed initial read" severity ERROR;
        wait for C_CLK_PERIOD; -- C0 FSM returns to IDLE

        -- Step 1.2: C1 Read Miss. C0 snoops BUS_RD and transitions E -> S. C1 transitions I -> S.
        report "T1.2 C1: Read Miss on 0x00. C0 Expect E -> S." severity NOTE;
        send_request(c1_proc_read_s, c1_proc_write_s, c1_proc_addr_s, c1_proc_data_in_s, 
                     true, CONFLICT_ADDR, DUMMY_DATA);
        -- The MC should see C0 hit, set shared_flag, and get data from Mem (or C0 if M).
        wait until c1_proc_ready_s = '1';
        assert c1_proc_data_out_s = X"00" report "T1.2 FAILED: C1 failed shared read" severity ERROR;
        wait for C_CLK_PERIOD; -- C1 FSM returns to IDLE
        
        -- Both Caches are now in the S state.

        -- =======================================================
        -- TEST 2: S -> M Transition (Write Upgrade and Invalidation)
        -- =======================================================
        report "--- TEST 2: C0 S->M, C1 S->I (Write Upgrade) ---" severity NOTE;

        -- Step 2.1: C0 Write Hit. State: S -> M (requires BUS_UPGR). C1 snoops UPGR and transitions S -> I.
        report "T2.1 C0: Write Hit on 0x00 (BUS_UPGR, data 0xAA)." severity NOTE;
        send_request(c0_proc_read_s, c0_proc_write_s, c0_proc_addr_s, c0_proc_data_in_s, 
                     false, CONFLICT_ADDR, C0_WRITE_DATA);

        -- Wait for C0 to complete UPGR_REQ/WAIT and local WRITE_HIT.
        wait until c0_proc_ready_s = '1';
        wait for C_CLK_PERIOD; -- C0 FSM returns to IDLE
        
        -- Cache C0 state should now be M. Cache C1 state should now be I.

        -- Step 2.2: C1 Read Miss (after invalidation). State: I -> S (Data from C0).
        -- C1 requests BUS_RD. MC sees C0 is M, forces C0 M->S, and routes data C0->C1.
        report "T2.2 C1: Read Miss on 0x00. Expect data 0xAA (Cache-to-Cache)." severity NOTE;
        send_request(c1_proc_read_s, c1_proc_write_s, c1_proc_addr_s, c1_proc_data_in_s, 
                     true, CONFLICT_ADDR, DUMMY_DATA);

        wait until c1_proc_ready_s = '1'; 
        -- Check if C1 received the modified data (0xAA) from C0.
        assert c1_proc_data_out_s = C0_WRITE_DATA report "T2.2 FAILED: C1 missed Cache-to-Cache read/wrong data" severity ERROR;
        wait for C_CLK_PERIOD; 

        -- Final states: C0 should be S. C1 should be S.

        -- =======================================================
        -- TEST 3: Dirty Line Transfer & Overwrite
        -- =======================================================
        report "--- TEST 3: C1 S->M, C0 S->I, C1 Writes (0xBB) ---" severity NOTE;

        -- Step 3.1: C1 Write Hit. State: S -> M (requires BUS_UPGR). C0 snoops UPGR and transitions S -> I.
        report "T3.1 C1: Write Hit on 0x00 (BUS_UPGR, data 0xBB)." severity NOTE;
        send_request(c1_proc_read_s, c1_proc_write_s, c1_proc_addr_s, c1_proc_data_in_s, 
                     false, CONFLICT_ADDR, C1_WRITE_DATA);
        wait until c1_proc_ready_s = '1';
        wait for C_CLK_PERIOD; -- C1 FSM returns to IDLE
        
        -- Cache C1 state is now M. Cache C0 state is now I.

        -- Step 3.2: C0 Read Miss. C1 must supply the dirty 0xBB data. C1 transitions M -> S. C0 transitions I -> S.
        report "T3.2 C0: Read Miss on 0x00. Expect data 0xBB (Cache-to-Cache)." severity NOTE;
        send_request(c0_proc_read_s, c0_proc_write_s, c0_proc_addr_s, c0_proc_data_in_s, 
                     true, CONFLICT_ADDR, DUMMY_DATA);
        wait until c0_proc_ready_s = '1'; 
        assert c0_proc_data_out_s = C1_WRITE_DATA report "T3.2 FAILED: C0 failed final Cache-to-Cache read" severity ERROR;
        wait for C_CLK_PERIOD; 
        
        report "--- All Dual-Core Coherence Tests Complete ---" severity NOTE;
        
        wait; -- End simulation
    end process stim_proc;

end Behavioral;